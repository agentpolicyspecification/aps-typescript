package aps.output

import data.aps.output.decision

import future.keywords.if
import future.keywords.in

blocked_domains := {"malicious.example", "phishing.example"}
